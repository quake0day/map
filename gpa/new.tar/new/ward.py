import os,sys,time

scaddress = '/home/gpa/new/judge.py &'

def ward():
	str0 = os.popen('ps aux | grep judge').readlines()
	#print str0
	print len(str0)
	if (len(str0) < 2):
		os.popen('python '+ scaddress)
	

def main():
	while 1: 
		ward()
		time.sleep(15) 

if '__main__' ==__name__:
	main()


