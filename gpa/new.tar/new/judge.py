import os 
import time 
import MySQLdb
import re
import os,sys
from time import sleep
from popen import _popen
from conn import connMysql
scaddress = '/home/gpa/new/scoreScanner.py'

def select_id_which_cal():
	conn2 = connMysql()
	cur = conn2.cursor()
	sql = "SELECT * FROM  `signup` WHERE  `set` =0 LIMIT 0 , 30"
	cur.execute(sql)
	data = cur.fetchone()
	try:
		len_t = len(data)
	except:
		len_t = 0
	if len_t != 0:			
				try:
					id = data[0]
				except:
					print "fuck id"
				userid = mytrim(data[1])
				passwd = mytrim(data[2])
				dust1 = '/usr/bin/python ' + scaddress
				dust2 = ' ' + userid +' '+ passwd + ' '+ str(id)
				dust = dust1 + dust2
				print dust
				try:
					str0 = int(_popen(dust).read())
                                        sleep(5)
				except:
					str0 = 1
				print str0
				if str0 != 2:
					if data[1] != '':
						updatewk = "UPDATE `chensi`.`signup` SET `set` = 1 where id= "+ str(data[0]) #when up to return True then change database "0" to "1"
					else:
						updatewk = "delete from `chensi`.`signup` where id= "+ str(data[0]) #when up to return True then change database "0" to "1"
				else:
					updatewk = "UPDATE `chensi`.`signup` SET `set` = 2 where id= "+ str(data[0])
				try:
					cur.execute(updatewk)
					print "hi"
				except:
					print 'fuckU'
				cur.close() 
				conn2.close()
				time.sleep(2)
	 

							
def main():
	while 1:
		select_id_which_cal()
		time.sleep(2) 
		
def mytrim(zstr):
	ystr=zstr.lstrip()
	ystr=ystr.rstrip()
	ystr=ystr.strip()
	return ystr
	
if '__main__' ==__name__:
	main()


