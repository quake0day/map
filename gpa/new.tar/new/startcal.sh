#!/bin/sh
nohup /usr/bin/python /home/cal/cal/judge.py &
